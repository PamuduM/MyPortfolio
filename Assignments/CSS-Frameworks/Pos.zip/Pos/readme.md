This is a Pos System Developed using bootstrap

#### Site Map :- https://drive.google.com/file/d/1va_bPni1wJbZS-HCtzo1Zg8_0ww_1IhL/view?usp=sharing


#### Wire Frame :- https://drive.google.com/file/d/1BNneCw5MeE_fgY_Gy9OE8e4DBsfS3nmw/view?usp=sharing


#### Mockup :- https://www.figma.com/file/oTh3d7gZHXU2NVyJc7oDyj/Pos-System-Mockup?type=design&node-id=0%3A1&t=IDYC1pOGHdQAGG8V-1